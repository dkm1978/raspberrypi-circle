#ifndef _SDCard_mmcerror_h
#define _SDCard_mmcerror_h

#define EINVAL		1
#define ETIMEDOUT	2
#define EILSEQ		3
#define ENOTSUP		4

#endif
