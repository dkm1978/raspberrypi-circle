#ifndef _linux_module_h
#define _linux_module_h

struct module
{
};

#define THIS_MODULE	0

#define EXPORT_SYMBOL(sym)

#define module_param(name, type, mode)
#define MODULE_PARM_DESC(name, desc)

#endif
