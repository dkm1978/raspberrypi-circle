#include <circle/util.h>
